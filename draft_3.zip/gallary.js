// gallery.js
function initGallery() {
    const items = document.querySelectorAll('.gallery-item');
    const detailsCard = document.querySelector('.details-card');
    const detailsName = document.querySelector('.details-name');
    const detailsCaption = document.querySelector('.details-caption');

    items.forEach(item => {
        item.addEventListener('click', () => {
            // Update details
            detailsName.textContent = item.dataset.name;
            detailsCaption.textContent = item.dataset.caption;
            
            // Toggle active state
            items.forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            detailsCard.classList.add('active');
            
            // Scroll to details on mobile
            if(window.innerWidth < 768) {
                detailsCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        });
    });

    // Close details on outside click
    document.addEventListener('click', (e) => {
        if(!e.target.closest('.gallery-item') && !e.target.closest('.details-card')) {
            detailsCard.classList.remove('active');
            items.forEach(i => i.classList.remove('active'));
        }
    });
}

document.addEventListener('DOMContentLoaded', initGallery);