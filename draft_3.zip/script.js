document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initLightbox();
    initDocumentSearch();
    initBackgroundSlider();
});

// Navigation Functionality
function initNavigation() {
    const hamburger = document.querySelector('.nav-hamburger');
    const navMenu = document.querySelector('.nav-menu');

    hamburger?.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    document.addEventListener('click', (e) => {
        if (!e.target.closest('.nav-container')) {
            hamburger?.classList.remove('active');
            navMenu?.classList.remove('active');
        }
    });
}

// Lightbox Functionality
function initLightbox() {
    const lightbox = document.createElement('div');
    lightbox.id = 'lightbox';
    document.body.appendChild(lightbox);

    document.querySelectorAll('.gallery-item img').forEach(img => {
        img.addEventListener('click', () => {
            lightbox.innerHTML = `<img src="${img.src}" alt="${img.alt}">`;
            lightbox.classList.add('active');
        });
    });

    lightbox.addEventListener('click', () => lightbox.classList.remove('active'));
}

// Document Search Functionality
function initDocumentSearch() {
    const searchInput = document.getElementById('searchInput');
    if (!searchInput) return;

    searchInput.addEventListener('input', function(e) {
        const term = e.target.value.toLowerCase().trim();
        const cards = document.querySelectorAll('.document-card');
        
        cards.forEach(card => {
            const cardText = card.textContent.toLowerCase();
            const isMatch = cardText.includes(term);
            
            card.style.display = isMatch ? 'block' : 'none';
            card.classList.toggle('search-match', isMatch);
            
            if (isMatch) {
                highlightSearchTerm(card, term);
            } else {
                removeHighlights(card);
            }
        });
    });
}

// Highlight Search Terms
function highlightSearchTerm(card, term) {
    const elements = card.querySelectorAll('h3, .document-description');
    elements.forEach(element => {
        const text = element.textContent;
        const regex = new RegExp(`(${term})`, 'gi');
        const highlighted = text.replace(regex, '<span class="highlight">$1</span>');
        element.innerHTML = highlighted;
    });
}

// Remove Highlights
function removeHighlights(card) {
    const highlights = card.querySelectorAll('.highlight');
    highlights.forEach(highlight => {
        const text = highlight.textContent;
        highlight.replaceWith(text);
    });
}

// Background Slider Functionality
function initBackgroundSlider() {
    const slides = document.querySelectorAll('.slide');
    if (!slides.length) return; // Exit if no slides found

    let currentSlide = 0;

    function showSlide(index) {
        slides.forEach((slide, i) => {
            slide.classList.toggle('active', i === index);
        });
    }

    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    }

    // Change slide every 3 seconds
    setInterval(nextSlide, 3000);

    // Initialize first slide
    showSlide(currentSlide);
}